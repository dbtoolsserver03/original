package com.ph.share.share.quartz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShareQuartzApplicationTests {

	@Test
	void contextLoads() {
	}

}
