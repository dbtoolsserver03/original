package com.suns.rpcgrpcbootclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpcGrpcBootClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
