package com.suns.service;

public interface OrderService {
    public void showOrder();
}
