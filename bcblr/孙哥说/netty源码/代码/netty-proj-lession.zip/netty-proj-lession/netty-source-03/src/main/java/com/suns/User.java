package com.suns;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class User {
    private String name;

}
